import React from 'react'

export default function InstrouctorProlife() {
  return (
    <div>
      <h1>kjkhgf</h1>
    </div>
  )
}
