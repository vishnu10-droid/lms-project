import React from 'react'

export default function StudentPayments() {
  return (
    <div>
     <h1>'jhugyt</h1>
    </div>
  )
}
