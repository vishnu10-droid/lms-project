import React from 'react'

export default function Schedule() {
  return (
    <div>
      <h1>kjhgfd</h1>
    </div>
  )
}
