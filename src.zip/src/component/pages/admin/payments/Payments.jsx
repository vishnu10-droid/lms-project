import React from 'react'

export default function Payments() {
  return (
    <div>
      <h1>mjhg</h1>
    </div>
  )
}
