import React from 'react';

const Certificate = () => {
  return (
    <div>
      <h1>Certificate</h1>
      <p>Certificate management here.</p>
    </div>
  );
};

export default Certificate;
