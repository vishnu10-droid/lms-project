import React from 'react'

export default function CourseAdd() {
  return (
    <div>
        <h1>kjhg</h1>
      
    </div>
  )
}
