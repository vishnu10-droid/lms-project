import React from 'react'

export default function CourseCategories() {
  return (
    <div>
      <h1>kjhgf</h1>
    </div>
  )
}
